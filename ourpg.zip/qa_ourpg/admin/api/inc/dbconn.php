<?php

// $hostname = "localhost";
// $username = "root";
// $password = "";
// $databaseName = "pg_management";


$hostname = "192.168.1.15";
$username = "root";
$password = "root";
$databaseName = "ourpg_qa";




	//Connecting to database
$link = mysql_connect($hostname, $username, $password); 
if (!$link) {

	die('Could not connect: ' . mysql_error());
}

mysql_select_db($databaseName); 

?>

