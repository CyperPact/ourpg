<?php
header('Content-Type: application/json');
// echo json_encode(array('foo' => 'bar'));
session_start();

$GLOBALS['isLoggedin'] = 0;

include "inc/dbconn.php";
include "inc/function.php";





// sec_session_start();

if (isset($_POST['action']) && !empty($_POST['action'])) {
    $action = $_POST['action'];
} elseif (isset($_GET['action']) && !empty($_GET['action'])) {
    $action = $_GET['action'];
}

switch ($action) {
    case 'uploadcsv':
    uploadcsv();
    break;
}


function checkLogin($userid, $token) {

    $getToken = singlefield("access_token", "user_info", "id='" . $userid . "' and active=1");

    if($getToken == $token) {
        return 1;
    } else {
        return 0;
    }
}




function uploadcsv() {

    $data = $_POST['params'];
    $someArray = json_decode($data, true);
    $userid = $someArray['userid'];
    $pg_id = $someArray['pg_id'];
    // $exp_type = $someArray['type'];
    $pg_info = $someArray['pg_info'];


    foreach (getallheaders() as $name => $value) {
        if($name == 'X-AUTH-TOKEN') {
            $token = $value;
        }
    }

    $validateUser = checkLogin($userid, $token);

    if($validateUser) {

        $table = "company_record";

        $columns = "`name`, `address_line_1`, `address_line_2`, `city`, `state`, `pincode`, `pg_type`, `contact_person`, `contact_number`, `contact_email`, `total_bed`, `registration_date`, `doc_id`, `modified_date`, `active`";

        $someArray = json_encode($data, true);

        foreach ($pg_info as $key => $value) {
            $pg_name = $value['name'];
            $address_line_1 = $value['address_line_1'];
            $address_line_2 = $value['address_line_2'];
            $city = $value['city'];
            $state = $value['state'];
            $pincode = $value['pincode'];
            $pg_type = $value['pg_type'];
            $contact_name = $value['contact_name'];
            $contact_number = $value['contact_number'];
            $contact_email = $value['contact_email'];
            $total_bed = $value['total_bed'];

            if($total_bed == "") {
                $total_bed = 0;
            }

            $doc_id = create_docid();

            $values = "'".$pg_name."', '".$address_line_1."', '".$address_line_2."', '".$city."', '".$state."', '".$pincode."', '".$pg_type."', '".$contact_name."', '".$contact_number."', '".$contact_email."', '".$total_bed."','".date("Y-m-d H:i:s")."', '".$doc_id."', '".date("Y-m-d H:i:s")."', '1'";

            if(insertrec($table, $columns, $values)) {
                $setFlag = true;
            } else {
                $setFlag = false;
            }

        }

        if($setFlag) {
            $arr = array('status' => 1, 'message' => 'Success');
        } else {
            $arr = array('status' => 0, 'message' => 'failure');
        }

    } else {
        $arr = array('status' => 404, 'message' => 'User not autheticated');
    }
    echo json_encode($arr);
}

function create_docid() {
    $doc_id = time() . '$' . uniqid() . '$' . md5(mt_rand());
    $check_docid = singlefield("id", "company_record", "doc_id='" . $doc_id . "' and active=1");
    if($check_docid) {
        create_docid();
    } else {
        return $doc_id;
    }
}


function registerNewPG() {
    $pg_name = "";
    $address_line_1 = "";
    $address_line_2 = "";
    $area = "";
    $city = "";
    $pin_code = "";
    $state = "";
    $country = "India";
    $contact_name = "";
    $owner_name = "-";
    $contact_number = "";
    $owner_number = "0";
    $contact_email = "";
    $total_bed = "";
    $pg_type = "";
    $usage_type = "";
    $payment_mode = "";
    $username = "";
    $password = "";

    $doc_id = create_docid();

    if (isset($_POST['pg_name'])) {$pg_name = urldecode($_POST['pg_name']);}
    if (isset($_POST['address_line_1'])) {$address_line_1 = urldecode($_POST['address_line_1']);}
    if (isset($_POST['address_line_2'])) {$address_line_2 = urldecode($_POST['address_line_2']);}
    //if (isset($_POST['area'])) {$area = urldecode($_POST['area']);}
    if (isset($_POST['city'])) {$city = urldecode($_POST['city']);}
    if (isset($_POST['pin_code'])) {$pin_code = urldecode($_POST['pin_code']);}
    if (isset($_POST['state'])) {$state = urldecode($_POST['state']);}
    //if (isset($_POST['country'])) {$country = urldecode($_POST['country']);}
    if (isset($_POST['contact_name'])) {$contact_name = urldecode($_POST['contact_name']);}
    if (isset($_POST['contact_number'])) {$contact_number = urldecode($_POST['contact_number']);}
    if (isset($_POST['contact_email'])) {$contact_email = urldecode($_POST['contact_email']);}
    //if (isset($_POST['contact_name'])) {$contact_name = urldecode($_POST['contact_name']);}
    //if (isset($_POST['contact_number'])) {$contact_number = urldecode($_POST['contact_number']);}
    if (isset($_POST['total_bed'])) {$total_bed = urldecode($_POST['total_bed']);}
    if (isset($_POST['pg_type'])) {$pg_type = urldecode($_POST['pg_type']);}
    if (isset($_POST['password'])) {$password = urldecode($_POST['password']);}
    //if (isset($_POST['usage_type'])) {$usage_type = urldecode($_POST['usage_type']);}
    //if (isset($_POST['payment_mode'])) {$payment_mode = urldecode($_POST['payment_mode']);}

    $table = "company_record";

    $columns = "`name`, `address_line_1`, `address_line_2`, `area`, `city`, `state`, `country`, `pincode`, `pg_type`, `owner_name`, `owner_number`, `contact_person`, `contact_number`, `contact_email`, `total_bed`, `usage_type`, `registration_date`, `mode_of_payment`, `doc_id`, `modified_date`, `active`";

    $values = "'".$pg_name."', '".$address_line_1."', '".$address_line_2."', '".$area."', '".$city."', '".$state."', '".$country."', '".$pin_code."', '".$pg_type."', '".$owner_name."', '".$owner_number."', '".$contact_name."', '".$contact_number."', '".$contact_email."', '".$total_bed."', '".$usage_type."', '".date("Y-m-d H:i:s")."', '".$payment_mode."', '".$doc_id."', '".date("Y-m-d H:i:s")."', '1'";


    $checkEmail = singlefield("id", "company_record", "contact_email='" . $contact_email . "' and active=1");

    if($checkEmail) {
        $arr = array('status' => 401, 'message' => 'Email id already registered.');
    } else {
        if (insertrec($table, $columns, $values)) {
            $user_table = "user_info";
            $user_columns = "`username`, `password`, `email_id`, `pg_id`, `active`";
            $user_values = "'".$contact_email."', '".md5($password)."', '".$contact_email."', '".$doc_id."', '1'";

            insertrec($user_table, $user_columns, $user_values);

            $arr = array('status' => 1, 'message' => 'Success');
        } else {
            $arr = array('status' => 0, 'message' => 'Failure');
        }
    }
    
    echo json_encode($arr);
}


function get_areas_pincode() {
    // echo "akshay";
    $rows = selectrec("`id`, `location`, `pincode`, `state`, `city`", "`tbl_area_codes`", "active=1" );
    $str = '{
        "category" : "Area-location List",
        "legend" : [ ';
        foreach ($rows as $row) {
            $str .= '{"id" : "'.$row[0].'", "value" : "'.$row[1].'", "data" : "'.$row[2].'", "state" : "'.$row[3].'", "city" : "'.$row[4].'"},';
        }


        if (count($rows) > 0)
            $str = substr($str, 0, -1);
        $str .= ']}';
        echo $str;    
    }


    function search_pg_on_pincode() {
        $city = $_GET["city"];
        $pincode = $_GET["pincode"];
        $type = $_GET["type"];
        $area_name = $_GET["area_name"];

        $rows = selectrec("`name`, `address_line_1`, `address_line_2`, `city`, `state`, `pincode`, `contact_person`, `contact_number`, `contact_email`, `id`", "`company_record`", "active=1 and city='".$city."' and pincode='".$pincode."' and pg_type='".$type."'" );

        $str = '{
            "category" : "Location Based PG Searcg",
            "area" : "'.$area_name.'",
            "pincode" : "'.$pincode.'",
            "legend" : [ ';
            foreach ($rows as $row) {
                $str .= '{"name" : "'.$row[0].'", "address_line_1" : "'.$row[1].'", "address_line_2" : "'.$row[2].'", "city" : "'.$row[3].'", "state" : "'.$row[4].'", "pincode" : "'.$row[5].'", "contact_person" : "'.$row[6].'", "contact_number" : "'.$row[7].'", "contact_email" : "'.$row[8].'", "id" : "'.$row[9].'", "price_range" : "", "facilities" : ""},';
            }


            if (count($rows) > 0)
                $str = substr($str, 0, -1);
            $str .= ']}';
            echo $str;    

        }



        ?>
